using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    //Variables Here!
    string enemyName = "Unknown Enemy";
    int vitality = 70;
    int physicalInstrument = 10;
    int painThreshold = 10;
    int endurance = 1;

    int volition = 1;

    //Then Methods!

    // Start is called before the first frame update
    void Start()
    {
   
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
